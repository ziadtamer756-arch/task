# PMP Multi-Agent AI System (نظام إدارة المشاريع الذكي متعدد الوكلاء)

نظام متقدم لإدارة وتحديث المشاريع يعتمد على معمارية الوكلاء المتعددين (Multi-Agent System) مع فصل صارم بين:
- **القواعد البرمجية الحتمية (Deterministic Code):** لضمان الأمان، تصنيف المسارات، ومنع الإجراءات الخطرة.
- **وكلاء الذكاء الاصطناعي (AI Agents):** للفهم، التحليل، كتابة التقارير، وفحص الهلوسة.
- **الإشراف البشري (Human-in-the-Loop):** لاعتماد القرارات الحرجة.

---

## 🏛️ المخطط المعماري للمشروع (Architecture Overview)

المشروع مبني وفقاً للمخططات المعمارية المعتمدة في ملفي:
- `PMP_Agent_Process_AR.drawio`
- `PMP_Agent_Process_EN.drawio`

### مراحل النظام (16 خطوة):
1. **Intake & Session:** استقبال التحديثات من (المورد، الموظف، المحاسب).
2. **Input Guardrail:** فحص الأمان واكتشاف محاولات حقن الأوامر (Prompt Injection) وحجز الرسائل المشبوهة.
3. **Extraction Agent:** استخراج المهام، المواعيد، والعوائق في صورة بيانات مهيكلة.
4. **Validation:** التحقق من اكتمال البيانات.
5. **Deterministic Router:** توجيه المسار برمجياً (عادي Normal vs حرج Critical Path).
6. **Project Orchestrator:** توزيع وتحديد الفحوصات المطلوبة.
7. **Parallel Checks:** 3 فحوصات بالتوازي (المهام، أحمال الفريق، مواعيد التسليم).
8. **Data Safety Scan:** فحص البيانات والتعليقات المجلوبة من النظام لمنع Indirect Prompt Injection.
9. **Risk Analysis Agent:** تجميع وتحليل المخاطر وترتيبها حسب الشدة.
10. **Deadline & Risk Rules:** حسابات برمجية رقمية دقيقة لمقارنة الأيام المتبقية بحجم العمل.
11. **Status Writer:** كتابة مسودة التقرير التنفيذي واقتراح الإجراءات.
12. **Evaluator Agent:** مطابقة كل جملة في التقرير مع بيانات المشروع الفعلية لمنع الهلوسة (حتى 3 محاولات).
13. **Output Guardrail:** منع الوعود غير المؤكدة أو ادعاء اكتمال المشروع 100% دون دليل نظامي.
14. **Action Gate:** بوابة سياسات حتمية (مسموح ALLOWED، يتطلب موافقة NEEDS_APPROVAL، ممنوع قطعي FORBIDDEN).
15. **Tools Execution:** التنفيذ الفعلي مع إعادة المحاولة مرتين عند الفشل.
16. **Final Result & Audit Trace:** التقرير النهائي وسجل التدقيق الشامل للمدير.

---

## 📂 هيكل المجلدات الحالي (Repository Structure)

```text
pmp_agent_system/
├── core/
│   ├── __init__.py           # تصدير الكائنات الأساسية
│   ├── models.py             # نماذج البيانات المهيكلة (Pydantic Schemas)
│   ├── guardrails.py         # متحكمات الأمان (Input Guardrail, Data Safety, Output Guardrail)
│   ├── router.py             # الموجه الحتمي للمسار العادي والحرج (Deterministic Router)
│   └── action_gate.py        # بوابة الإجراءات والسياسات (Action Gate Policy Engine)
├── tests/
│   ├── __init__.py
│   └── test_core.py          # اختبارات الوحدة لحالات الاستخدام الواقعية (Cases 2, 3, 5, 6, 7, 8)
└── README.md
```

---

## 🚀 كيفية تشغيل الاختبارات (Running Tests)

من المجلد الرئيسي للمشروع:
```bash
python -m unittest pmp_agent_system/tests/test_core.py
```

---

## 🤝 المهام المتبقية لزميلك (Tasks for Collaborator @zyadwaled780-cmd)

تم بناء النواة الصلبة ونماذج الأمان بالكامل. المهام التالية جاهزة للتنفيذ:
1. **بناء الوكلاء (Agents Implementation):**
   - `agents/extraction_agent.py`: استدعاء نموذج LLM لتحويل النص الحر إلى كائن `ExtractedUpdate`.
   - `agents/risk_analyzer.py`: تقييم المخاطر وترتيبها في قائمة `List[RiskItem]`.
   - `agents/status_writer.py`: صياغة مسودة التقرير التنفيذي `ExecutiveReport`.
   - `agents/evaluator_agent.py`: فحص التقرير ومطابقته لمنع الهلوسة مع حلقة التكرار (3 attempts loop).
2. **الفحوصات المتوازية (Checks Implementation):**
   - `checks/task_checker.py`: جلب وفحص المهام المتأخرة.
   - `checks/team_checker.py`: تحليل أحمال الفريق وتوزيع المهام.
   - `checks/deadline_checker.py`: معادلات الحساب الرقمي لمواعيد التسليم.
3. **أدوات التنفيذ (Tools Execution):**
   - `tools/execution_tools.py`: تنفيذ إجراءات إضافة التعليقات وتحديث المهام مع دعم Retry Mechanism.
